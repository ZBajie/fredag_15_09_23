# 13-september

## Övningar
Fredagens övning https://gist.github.com/Andreas-Zocom/e4c86d2cc749afa946a3d07db95ebaba
## Artiklar

HTML element: https://developer.mozilla.org/en-US/docs/Web/HTML/Element

## Videor

Programming mindset: https://www.youtube.com/watch?v=rWMuEIcdJP4&t=24s&pp=ygUSY29kZWNhZGVteSBtaW5kc2V0
